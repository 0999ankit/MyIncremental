export const environment = {
  production: false,
  apiUrl: window.location.origin.replace("3000", "5000"),
};
